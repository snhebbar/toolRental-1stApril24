package com.tools.rental.admin.brand;

import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@Data
public class ToolBrandBean {

    protected Integer id;


    private String brandCode;


    private String name;


    private String descriptions;


}
