package com.tools.rental.service;

import com.tools.rental.model.entity.ToolDetailsBean;

public interface ToolService {

    public ToolDetailsBean toolDetailsByCode(String code);


}
